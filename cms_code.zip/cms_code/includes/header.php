<!DOCTYPE html>
<html lang="en">
<head>
    <!-- basic meta information, including title in browser and link to stylesheets-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Art Blog Home</title>
    <link rel="stylesheet" href="css/styles.css?id=777" type="text/css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <!-- link to access special google fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Crimson+Text:ital,wght@0,400;0,600;0,700;1,400;1,600;1,700&family=Texturina:ital,opsz,wght@0,12..72,100..900;1,12..72,100..900&display=swap" rel="stylesheet">
</head>

<body>
    <!-- basic layout for nav header section on each page -->
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="art.php">Art</a></li>
            <li><a href="writing.php">Writing</a></li>
            <li><a href="all.php">All Posts</a></li>
            <li><a href="userauth.php">Admin</a></li>
        </ul>
    </nav>


