<?php
function getPosts($conn, $limit = 5) {
    $query = "SELECT * FROM posts ORDER BY created_at DESC LIMIT $limit";
    return mysqli_query($conn, $query);
}
?>